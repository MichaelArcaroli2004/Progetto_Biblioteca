﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Biblioteca_Bros_e_Arcaroli_Libreria
{
    
   public class Biblioteca
    {
        List<utenti> LstUtenti =new List<utenti>();
        List<Documenti> LstDocumenti = new List<Documenti>();
        public void AddUtenti(utenti u)
        {
            LstUtenti.Add(u);
        }
        public void AddDocumenti(Documenti d)
        {
            LstDocumenti.Add(d);
        }
    }
    class Documenti 
    {
        public string Codice { get; set;}
        public string Titolo { get; set; }
        public bool Stato { get; set; }
        public string Autore { get; set; }
        public int Scaffale { get; set; }

        List<Libri> LstLibri = new List<Libri>();
        List<DVD> LstDVD = new List<DVD>();
        public void AddLibri(Libri l)
        {
            LstLibri.Add(l);
        }
        public void AddDVD(DVD dvd)
        {
            LstDVD.Add(dvd);
        }
    }
    class Libri 
    {
    public string ISBN { get; set; }
        int pagine;
    }
    class DVD
    {
        public string numeroSeriale { get; set; }
        int durata;
    }
    class Prestito 
    {
        public DateTime dataPrestito { get; set; }
        public DateTime dataRestituzione { get; set; }
    }
    class utenti 
    {
    public string Password { get; set; }
        List<Documenti> lstDocumentiInPossesso = new List<Documenti>();
    }
    class Persona 
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string NumeroDiTelefono { get; set; }
        public string Email { get; set; }
    }
}

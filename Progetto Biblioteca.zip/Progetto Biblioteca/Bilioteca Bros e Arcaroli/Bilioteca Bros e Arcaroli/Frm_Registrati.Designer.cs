﻿namespace Bilioteca_Bros_e_Arcaroli
{
    partial class Frm_Registrati
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txt_Cognome = new System.Windows.Forms.TextBox();
            this.lbl_Cognome = new System.Windows.Forms.Label();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Telefono = new System.Windows.Forms.Label();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.btn_Registrati = new System.Windows.Forms.Button();
            this.btn_Indietro = new System.Windows.Forms.Button();
            this.Registrati = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Location = new System.Drawing.Point(50, 43);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(40, 15);
            this.lbl_Nome.TabIndex = 0;
            this.lbl_Nome.Text = "Nome";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(50, 71);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(207, 23);
            this.txt_Nome.TabIndex = 1;
            // 
            // txt_Cognome
            // 
            this.txt_Cognome.Location = new System.Drawing.Point(50, 132);
            this.txt_Cognome.Name = "txt_Cognome";
            this.txt_Cognome.Size = new System.Drawing.Size(207, 23);
            this.txt_Cognome.TabIndex = 2;
            // 
            // lbl_Cognome
            // 
            this.lbl_Cognome.AutoSize = true;
            this.lbl_Cognome.Location = new System.Drawing.Point(50, 114);
            this.lbl_Cognome.Name = "lbl_Cognome";
            this.lbl_Cognome.Size = new System.Drawing.Size(60, 15);
            this.lbl_Cognome.TabIndex = 3;
            this.lbl_Cognome.Text = "Cognome";
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(50, 191);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(207, 23);
            this.txt_Email.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Email";
            // 
            // lbl_Telefono
            // 
            this.lbl_Telefono.AutoSize = true;
            this.lbl_Telefono.Location = new System.Drawing.Point(52, 225);
            this.lbl_Telefono.Name = "lbl_Telefono";
            this.lbl_Telefono.Size = new System.Drawing.Size(111, 15);
            this.lbl_Telefono.TabIndex = 6;
            this.lbl_Telefono.Text = "Numero di telefono";
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(50, 253);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(207, 23);
            this.txt_Telefono.TabIndex = 7;
            // 
            // btn_Registrati
            // 
            this.btn_Registrati.Location = new System.Drawing.Point(50, 304);
            this.btn_Registrati.Name = "btn_Registrati";
            this.btn_Registrati.Size = new System.Drawing.Size(151, 64);
            this.btn_Registrati.TabIndex = 8;
            this.btn_Registrati.Text = "Registrati";
            this.btn_Registrati.UseVisualStyleBackColor = true;
            // 
            // btn_Indietro
            // 
            this.btn_Indietro.Location = new System.Drawing.Point(50, 374);
            this.btn_Indietro.Name = "btn_Indietro";
            this.btn_Indietro.Size = new System.Drawing.Size(151, 64);
            this.btn_Indietro.TabIndex = 9;
            this.btn_Indietro.Text = "Indietro";
            this.btn_Indietro.UseVisualStyleBackColor = true;
            // 
            // Registrati
            // 
            this.Registrati.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Registrati.Location = new System.Drawing.Point(42, -4);
            this.Registrati.Name = "Registrati";
            this.Registrati.Size = new System.Drawing.Size(159, 38);
            this.Registrati.TabIndex = 10;
            this.Registrati.Text = "Registrati";
            // 
            // Frm_Registrati
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 450);
            this.Controls.Add(this.Registrati);
            this.Controls.Add(this.btn_Indietro);
            this.Controls.Add(this.btn_Registrati);
            this.Controls.Add(this.txt_Telefono);
            this.Controls.Add(this.lbl_Telefono);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.lbl_Cognome);
            this.Controls.Add(this.txt_Cognome);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.lbl_Nome);
            this.Name = "Frm_Registrati";
            this.Text = "Frm_Registrati";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.TextBox txt_Cognome;
        private System.Windows.Forms.Label lbl_Cognome;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Telefono;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.Button btn_Registrati;
        private System.Windows.Forms.Button btn_Indietro;
        private System.Windows.Forms.Label Registrati;
    }
}
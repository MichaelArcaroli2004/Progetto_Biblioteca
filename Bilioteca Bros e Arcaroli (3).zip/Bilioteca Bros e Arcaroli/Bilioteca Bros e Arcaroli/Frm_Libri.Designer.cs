﻿namespace Bilioteca_Bros_e_Arcaroli
{
    partial class Frm_Libri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Aggiungi = new System.Windows.Forms.Button();
            this.btn_Indietro = new System.Windows.Forms.Button();
            this.lbl_TitoloLibro = new System.Windows.Forms.Label();
            this.lbl_Titolo = new System.Windows.Forms.Label();
            this.lbl_Genere = new System.Windows.Forms.Label();
            this.lbl_NumPagine = new System.Windows.Forms.Label();
            this.lbl_Codice = new System.Windows.Forms.Label();
            this.lbl_GenereLibro = new System.Windows.Forms.Label();
            this.lbl_NumPagineLibro = new System.Windows.Forms.Label();
            this.lbl_CodiceLibro = new System.Windows.Forms.Label();
            this.lbl_AutoreLibro = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Aggiungi
            // 
            this.btn_Aggiungi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Aggiungi.Location = new System.Drawing.Point(175, 208);
            this.btn_Aggiungi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Aggiungi.Name = "btn_Aggiungi";
            this.btn_Aggiungi.Size = new System.Drawing.Size(82, 22);
            this.btn_Aggiungi.TabIndex = 0;
            this.btn_Aggiungi.Text = "Aggiungi";
            this.btn_Aggiungi.UseVisualStyleBackColor = true;
            // 
            // btn_Indietro
            // 
            this.btn_Indietro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Indietro.Location = new System.Drawing.Point(32, 208);
            this.btn_Indietro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Indietro.Name = "btn_Indietro";
            this.btn_Indietro.Size = new System.Drawing.Size(82, 22);
            this.btn_Indietro.TabIndex = 1;
            this.btn_Indietro.Text = "Indietro";
            this.btn_Indietro.UseVisualStyleBackColor = true;
            // 
            // lbl_TitoloLibro
            // 
            this.lbl_TitoloLibro.AutoSize = true;
            this.lbl_TitoloLibro.Location = new System.Drawing.Point(127, 10);
            this.lbl_TitoloLibro.Name = "lbl_TitoloLibro";
            this.lbl_TitoloLibro.Size = new System.Drawing.Size(38, 15);
            this.lbl_TitoloLibro.TabIndex = 11;
            this.lbl_TitoloLibro.Text = "label1";
            // 
            // lbl_Titolo
            // 
            this.lbl_Titolo.AutoSize = true;
            this.lbl_Titolo.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Titolo.Location = new System.Drawing.Point(32, 8);
            this.lbl_Titolo.Name = "lbl_Titolo";
            this.lbl_Titolo.Size = new System.Drawing.Size(50, 20);
            this.lbl_Titolo.TabIndex = 12;
            this.lbl_Titolo.Text = "Titolo";
            // 
            // lbl_Genere
            // 
            this.lbl_Genere.AutoSize = true;
            this.lbl_Genere.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Genere.Location = new System.Drawing.Point(32, 44);
            this.lbl_Genere.Name = "lbl_Genere";
            this.lbl_Genere.Size = new System.Drawing.Size(59, 20);
            this.lbl_Genere.TabIndex = 13;
            this.lbl_Genere.Text = "Genere";
            // 
            // lbl_NumPagine
            // 
            this.lbl_NumPagine.AutoSize = true;
            this.lbl_NumPagine.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_NumPagine.Location = new System.Drawing.Point(32, 81);
            this.lbl_NumPagine.Name = "lbl_NumPagine";
            this.lbl_NumPagine.Size = new System.Drawing.Size(118, 20);
            this.lbl_NumPagine.TabIndex = 14;
            this.lbl_NumPagine.Text = "Numero pagine";
            // 
            // lbl_Codice
            // 
            this.lbl_Codice.AutoSize = true;
            this.lbl_Codice.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Codice.Location = new System.Drawing.Point(32, 122);
            this.lbl_Codice.Name = "lbl_Codice";
            this.lbl_Codice.Size = new System.Drawing.Size(55, 20);
            this.lbl_Codice.TabIndex = 15;
            this.lbl_Codice.Text = "Codice";
            // 
            // lbl_GenereLibro
            // 
            this.lbl_GenereLibro.AutoSize = true;
            this.lbl_GenereLibro.Location = new System.Drawing.Point(127, 47);
            this.lbl_GenereLibro.Name = "lbl_GenereLibro";
            this.lbl_GenereLibro.Size = new System.Drawing.Size(38, 15);
            this.lbl_GenereLibro.TabIndex = 16;
            this.lbl_GenereLibro.Text = "label2";
            // 
            // lbl_NumPagineLibro
            // 
            this.lbl_NumPagineLibro.AutoSize = true;
            this.lbl_NumPagineLibro.Location = new System.Drawing.Point(175, 85);
            this.lbl_NumPagineLibro.Name = "lbl_NumPagineLibro";
            this.lbl_NumPagineLibro.Size = new System.Drawing.Size(38, 15);
            this.lbl_NumPagineLibro.TabIndex = 17;
            this.lbl_NumPagineLibro.Text = "label3";
            // 
            // lbl_CodiceLibro
            // 
            this.lbl_CodiceLibro.AutoSize = true;
            this.lbl_CodiceLibro.Location = new System.Drawing.Point(115, 124);
            this.lbl_CodiceLibro.Name = "lbl_CodiceLibro";
            this.lbl_CodiceLibro.Size = new System.Drawing.Size(38, 15);
            this.lbl_CodiceLibro.TabIndex = 18;
            this.lbl_CodiceLibro.Text = "label4";
            // 
            // lbl_AutoreLibro
            // 
            this.lbl_AutoreLibro.AutoSize = true;
            this.lbl_AutoreLibro.Location = new System.Drawing.Point(118, 163);
            this.lbl_AutoreLibro.Name = "lbl_AutoreLibro";
            this.lbl_AutoreLibro.Size = new System.Drawing.Size(38, 15);
            this.lbl_AutoreLibro.TabIndex = 20;
            this.lbl_AutoreLibro.Text = "label5";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(36, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "Autore";
            // 
            // Frm_Libri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 253);
            this.Controls.Add(this.lbl_AutoreLibro);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_CodiceLibro);
            this.Controls.Add(this.lbl_NumPagineLibro);
            this.Controls.Add(this.lbl_GenereLibro);
            this.Controls.Add(this.lbl_Codice);
            this.Controls.Add(this.lbl_NumPagine);
            this.Controls.Add(this.lbl_Genere);
            this.Controls.Add(this.lbl_Titolo);
            this.Controls.Add(this.lbl_TitoloLibro);
            this.Controls.Add(this.btn_Indietro);
            this.Controls.Add(this.btn_Aggiungi);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Frm_Libri";
            this.Text = "Frm_Libri";
            this.Load += new System.EventHandler(this.Frm_Libri_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Aggiungi;
        private System.Windows.Forms.Button btn_Indietro;
        private System.Windows.Forms.Label lbl_TitoloLibro;
        private System.Windows.Forms.Label lbl_Titolo;
        private System.Windows.Forms.Label lbl_Genere;
        private System.Windows.Forms.Label lbl_NumPagine;
        private System.Windows.Forms.Label lbl_Codice;
        private System.Windows.Forms.Label lbl_GenereLibro;
        private System.Windows.Forms.Label lbl_NumPagineLibro;
        private System.Windows.Forms.Label lbl_CodiceLibro;
        private System.Windows.Forms.Label lbl_AutoreLibro;
        private System.Windows.Forms.Label label2;
    }
}
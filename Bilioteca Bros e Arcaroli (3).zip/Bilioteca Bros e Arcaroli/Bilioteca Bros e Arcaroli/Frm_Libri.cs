﻿using Biblioteca_Bros_e_Arcaroli_Libreria;
using System;
using System.Windows.Forms;

namespace Bilioteca_Bros_e_Arcaroli
{
    public partial class Frm_Libri : Form
    {
        Biblioteca b = new Biblioteca();

        public Frm_Libri(Biblioteca biblio)
        {
            InitializeComponent();
            b = biblio;
        }

        private void label2_Click(object sender, EventArgs e)
        { // vengono mostrati tutte le carateristiche dei libri
        }

        private void Frm_Libri_Load(object sender, EventArgs e)
        {
            lbl_TitoloLibro.Text = b.publicLstLibri[b.NumeroLibroSelezionato].Titolo;
            lbl_NumPagineLibro.Text = $"{b.publicLstLibri[b.NumeroLibroSelezionato].Pagine}";
            lbl_GenereLibro.Text = b.publicLstLibri[b.NumeroLibroSelezionato].Genere;
            lbl_AutoreLibro.Text = b.publicLstLibri[b.NumeroLibroSelezionato].Autore;
            lbl_CodiceLibro.Text = b.publicLstLibri[b.NumeroLibroSelezionato].ISBN;
        }
    }
}

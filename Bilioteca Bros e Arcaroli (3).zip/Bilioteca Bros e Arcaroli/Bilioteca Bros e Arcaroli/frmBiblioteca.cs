﻿using Biblioteca_Bros_e_Arcaroli_Libreria;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Bilioteca_Bros_e_Arcaroli
{
    public partial class frmBiblioteca : Form
    {
        Biblioteca b = new Biblioteca();
        public frmBiblioteca(Biblioteca biblio)
        {
            InitializeComponent();
            b = biblio;
        }

        private void frmBiblioteca_Load(object sender, EventArgs e)
        {
            // viene richiamato il metodo CreaLibro per generare dei libri casualmete 
            b.CreaLibro(10);
            cmb_OrdineLibri.Items.Add("Nome");
            cmb_OrdineLibri.Items.Add("Lunghezza");
            cmb_OrdineLibri.Items.Add("Genere");
            bool c = false;
            // crea una campo di pulsanti con illinterno il titolo del libro
            for (int i = 0; i < 10; i++)
            {
                for (int l = 0; l < 15; l++)
                {

                    try
                    {
                        Button t = new Button();//creazione del pulsante in modo dinamico
                        this.Controls.Add(t);
                        t.Height = 110; t.Width = 80; t.Top = 140 + i * 90; t.Left = 40 + l * 90;//viene gestita la grandezza e la distanza dei pulsanti
                        t.Tag = $"{i},{l}";//altezza e lunghezza del campo di pulsanti 
                        t.Text = b.publicLstLibri[(i + 1) * l].Titolo;//vengono inseriti il titolo dalla classe CreaLibro
                        b.NumeroLibroSelezionato = (i + 1) * l;
                        t.Click += new System.EventHandler(Cliccato); //il bottone richiama il metodo "Cliccato"
                    }
                    catch
                    {
                        c = true;
                        break;
                    }
                }
                if (c == true)
                {
                    break;
                }
            }
        }
        public void Cliccato(object sender, EventArgs e)
        {
            Frm_Libri libri = new Frm_Libri(b);
            libri.Show();
        }
        private void pct_ImmagineUtente_Click(object sender, EventArgs e)
        {   //mostra le infformazione di registrazione dell'untente 
            frm_DatiUtente datiutente = new frm_DatiUtente(b);
            datiutente.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        { // una texbox che server per cercare i libri per il loro titolo 
            lst_NomiLibriRicerca.Visible = true;
            List<Libro> libriTrovati = new List<Libro>();
            Random random = new Random();
            if (txt_Cerca.Text == "")
            {
                lst_NomiLibriRicerca.DataSource = null;
            }
            else
            {
                for (int i = 0; i < b.publicLstLibri.Count; i++)
                {
                    for (int k = 0; k < txt_Cerca.Text.Length; k++)
                    {
                        if (b.publicLstLibri[i].Titolo[k] == txt_Cerca.Text[k])
                        {
                            libriTrovati.Add(b.publicLstLibri[i]);
                            lst_NomiLibriRicerca.DataSource = null;
                            lst_NomiLibriRicerca.DataSource = libriTrovati;
                        }
                    }
                }
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Biblioteca_Bros_e_Arcaroli_Libreria
{
    public class Biblioteca
    {
        List<utenti> LstUtenti = new List<utenti>();
        List<Documenti> LstDocumenti = new List<Documenti>();
        public DateTime dataPrestito { get; set; }
        public DateTime dataRestituzione { get; set; }
        public int NUMEROUTENTE { get; set; }
        public List<utenti> publicLstUtenti { get { return LstUtenti; } }
        public List<Documenti> publicLstDocumenti { get { return LstDocumenti; } }

        public void Prestito()
        {
            dataPrestito = DateTime.Now;
            dataRestituzione = DateTime.Now;
            dataRestituzione.AddMonths(1);
        }
        public void AddUtenti(utenti u)
        {
            LstUtenti.Add(u);
        }
        public void AddDocumenti(Documenti d)
        {
            LstDocumenti.Add(d);
        }
        public void CreaNome() 
        {
            string[] articoloMaschileSingolare = new string[] { "Il","L'","Un", " Lo", "Uno" };
            string[] articoloMaschilePlurale = new string[] {"Gli","I","Alcuni"};
            string[] articoloFemminileSingolare = new string[] { "L'", "un'" , "La","una" };
            string[] articoloFemminilePlurale = new string[] { "Alcune","Le"};
            string[] NomeMaschileSingolare = new string[] { "gatto", "bambino", "gallo", "leone", "toro", "cane", "gnomo", "ariete", "elefante" };
            string[] NomeMaschilePlurale = new string[] { "ragazzi", "grilli", "cuochi", "polli", "studenti" };
            string[] NomeFemminileSingolare = new string[] { "gatta", "gallina", "mucca", "regina", "volpe", "dottoressa", "psicologa", "iena", "elefantessa" };
            string[] NomeFemminilePlurale = new string[] { "tigri", "persone", "giraffe", "api", "oche"};
            string[] AggettivoMaschileSingolare = new string[] { "maldestro", "squilibrato", "affascinante", "affidabile", "abile", "inaffidabile", "allegro" };
            string[] AggettivoFemminileSingolare = new string[] {"bella", "brutta", "scomntrosa", "malvagia", "carismatica", "fedele", "coraggiosa","divertente", "egoista", "introversa"};
            string[] AggettivoMaschilePlurale = new string[] { "divertenti", "squilibrati", "fedeli", "gioiosi", "tristi", "introversi", "assassini" };
            string[] AggettivoFemminilePlurale = new string[] {"paurose", "pericolose", "premurose", "bugiarde", "impavide ", "intelligenti", "orgogliose" };
            Random frase = new Random();

            for (int i = 0; i < 5; i++)
            {
                string titoloMS = $"{articoloMaschileSingolare[frase.Next(articoloMaschileSingolare.Length)]} {NomeMaschileSingolare[frase.Next(NomeMaschileSingolare.Length)]} {AggettivoMaschileSingolare[frase.Next(AggettivoMaschileSingolare.Length)]}";
                string titoloMP = $"{articoloMaschilePlurale[frase.Next(articoloMaschilePlurale.Length)]} {NomeMaschilePlurale[frase.Next(NomeMaschilePlurale.Length)]} {AggettivoMaschilePlurale[frase.Next(AggettivoMaschilePlurale.Length)]}";
                string titoloFS = $"{articoloFemminileSingolare[frase.Next(articoloFemminileSingolare.Length)]} {NomeFemminileSingolare[frase.Next(NomeFemminileSingolare.Length)]} {AggettivoFemminileSingolare[frase.Next(AggettivoFemminileSingolare.Length)]}";
                string titoloFP = $"{articoloFemminilePlurale[frase.Next(articoloFemminilePlurale.Length)]} {NomeFemminilePlurale[frase.Next(NomeFemminilePlurale.Length)]} {AggettivoFemminilePlurale[frase.Next(AggettivoFemminilePlurale.Length)]}";
            }
        }
        public void CreaLibro()
        {

        }
    }
    public class Documenti
    {
        public string Codice { get; set; }
        public string Titolo { get; set; }
        public string Autore { get; set; }
        public bool Stato { get; set; }
        public int Scaffale { get; set; }

        List<Libri> LstLibri = new List<Libri>();
        List<DVD> LstDVD = new List<DVD>();
        public Documenti(string codice, string titolo, string autore) 
        {
            this.Codice = codice;
            this.Titolo = titolo;
            this.Autore = autore;
        }
        public void AddLibri(Libri l)
        {
            LstLibri.Add(l);
        }
        public void AddDVD(DVD d)
        {
            LstDVD.Add(d);
        }
    }   
    public class Libri : Documenti
    {
        public string ISBN { get; set; }
        int pagine;

        public Libri(string isbn, int pagine, string codice, string titolo, string autore) : base(codice, titolo, autore)
        {
            this.ISBN = isbn;
            this.pagine = pagine;
        }
    }
    public class DVD : Documenti
    {
        public string numeroSeriale { get; set; }
        int durata;
        public DVD(string numeroSeriale, int durata, string codice, string titolo, string autore) : base(codice, titolo, autore)
        {
            this.numeroSeriale = numeroSeriale;
            this.durata = durata;
        }
    }
    public class utenti : Persona
    {
        public string Password { get; set; }
        List<Documenti> lstDocumentiInPossesso = new List<Documenti>();
    }
    public class Persona
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string NumeroDiTelefono { get; set; }
        public string Email { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using Biblioteca_Bros_e_Arcaroli_Libreria;
using System.Windows.Forms;

namespace Bilioteca_Bros_e_Arcaroli
{
    public partial class frmBiblioteca : Form
    {
        Biblioteca b = new Biblioteca();
        public frmBiblioteca(Biblioteca biblio)
        {
            InitializeComponent();
            b = biblio;
        }

        private void frmBiblioteca_Load(object sender, EventArgs e)
        {
        }
        private void pct_ImmagineUtente_Click(object sender, EventArgs e)
        {
            frm_DatiUtente datiutente = new frm_DatiUtente(b);
            datiutente.Show();
        }
    }
}

﻿
namespace Bilioteca_Bros_e_Arcaroli
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_Registrati = new System.Windows.Forms.Button();
            this.lbl_Biblioteca = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(26, 116);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(197, 90);
            this.btn_Login.TabIndex = 0;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Registrati
            // 
            this.btn_Registrati.Location = new System.Drawing.Point(312, 116);
            this.btn_Registrati.Name = "btn_Registrati";
            this.btn_Registrati.Size = new System.Drawing.Size(197, 90);
            this.btn_Registrati.TabIndex = 1;
            this.btn_Registrati.Text = "Registrati";
            this.btn_Registrati.UseVisualStyleBackColor = true;
            this.btn_Registrati.Click += new System.EventHandler(this.btn_Registrati_Click);
            // 
            // lbl_Biblioteca
            // 
            this.lbl_Biblioteca.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Biblioteca.Location = new System.Drawing.Point(164, 11);
            this.lbl_Biblioteca.Name = "lbl_Biblioteca";
            this.lbl_Biblioteca.Size = new System.Drawing.Size(233, 73);
            this.lbl_Biblioteca.TabIndex = 2;
            this.lbl_Biblioteca.Text = "Biblioteca";
            this.lbl_Biblioteca.Click += new System.EventHandler(this.lbl_Biblioteca_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 257);
            this.Controls.Add(this.lbl_Biblioteca);
            this.Controls.Add(this.btn_Registrati);
            this.Controls.Add(this.btn_Login);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_Registrati;
        private System.Windows.Forms.Label lbl_Biblioteca;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using Biblioteca_Bros_e_Arcaroli_Libreria;
using System.Windows.Forms;


namespace Bilioteca_Bros_e_Arcaroli
{
    public partial class Frm_Registrati : Form
    {
        Biblioteca b = new Biblioteca();
        public Frm_Registrati(Biblioteca biblio)
        {
            InitializeComponent();
            b = biblio;

        }

        private void btn_Indietro_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void btn_PagLogin_Click(object sender, EventArgs e)
        {
            Frm_Login frm = new Frm_Login(b);
            frm.ShowDialog();
        }


        private void btn_Registrati_Click(object sender, EventArgs e)
        {
            if (txt_Telefono.Text == "" || txt_Email.Text == "" || txt_Cognome.Text == "" || txt_Nome.Text == "" || txt_Password.Text == "")
            {
                MessageBox.Show("Mancano dei Dati");
            }
            else
            {
                utenti u = new utenti();
                u.NumeroDiTelefono = txt_Telefono.Text;
                u.Email = txt_Email.Text;
                u.Cognome = txt_Cognome.Text;
                u.Nome = txt_Nome.Text;
                u.Password = txt_Password.Text;
                b.AddUtenti(u);
                Close();
            }
        }

        private void Frm_Registrati_Load(object sender, EventArgs e)
        {

        }
    }
}

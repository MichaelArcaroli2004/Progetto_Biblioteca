﻿
namespace Bilioteca_Bros_e_Arcaroli
{
    partial class frmBiblioteca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pct_ImmagineUtente = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pct_ImmagineUtente)).BeginInit();
            this.SuspendLayout();
            // 
            // pct_ImmagineUtente
            // 
            this.pct_ImmagineUtente.Image = global::Bilioteca_Bros_e_Arcaroli.Properties.Resources.utente;
            this.pct_ImmagineUtente.Location = new System.Drawing.Point(768, 12);
            this.pct_ImmagineUtente.Name = "pct_ImmagineUtente";
            this.pct_ImmagineUtente.Size = new System.Drawing.Size(49, 48);
            this.pct_ImmagineUtente.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pct_ImmagineUtente.TabIndex = 0;
            this.pct_ImmagineUtente.TabStop = false;
            this.pct_ImmagineUtente.Click += new System.EventHandler(this.pct_ImmagineUtente_Click);
            // 
            // frmBiblioteca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 447);
            this.Controls.Add(this.pct_ImmagineUtente);
            this.Name = "frmBiblioteca";
            this.Text = "frmBiblioteca";
            this.Load += new System.EventHandler(this.frmBiblioteca_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pct_ImmagineUtente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.PictureBox pct_ImmagineUtente;
    }
}
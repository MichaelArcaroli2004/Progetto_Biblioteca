﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using Biblioteca_Bros_e_Arcaroli_Libreria;
using System.Windows.Forms;

namespace Bilioteca_Bros_e_Arcaroli
{
    public partial class frm_LibriPersonali : Form
    {
        Biblioteca b = new Biblioteca();

        public frm_LibriPersonali(Biblioteca biblio)
        {
            InitializeComponent();
            b = biblio;
        }

        private void pct_home_Click(object sender, EventArgs e)
        {
            frmBiblioteca f = new frmBiblioteca(b);
            this.Visible = false;
            f.ShowDialog();
            
        }
    }
}

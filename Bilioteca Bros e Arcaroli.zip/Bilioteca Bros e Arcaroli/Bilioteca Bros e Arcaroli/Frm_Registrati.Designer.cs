﻿namespace Bilioteca_Bros_e_Arcaroli
{
    partial class Frm_Registrati
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txt_Cognome = new System.Windows.Forms.TextBox();
            this.lbl_Cognome = new System.Windows.Forms.Label();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Telefono = new System.Windows.Forms.Label();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.btn_Registrati = new System.Windows.Forms.Button();
            this.btn_Indietro = new System.Windows.Forms.Button();
            this.Registrati = new System.Windows.Forms.Label();
            this.btn_PagLogin = new System.Windows.Forms.Button();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Location = new System.Drawing.Point(57, 57);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(50, 20);
            this.lbl_Nome.TabIndex = 0;
            this.lbl_Nome.Text = "Nome";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(57, 95);
            this.txt_Nome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(236, 27);
            this.txt_Nome.TabIndex = 1;
            // 
            // txt_Cognome
            // 
            this.txt_Cognome.Location = new System.Drawing.Point(57, 176);
            this.txt_Cognome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Cognome.Name = "txt_Cognome";
            this.txt_Cognome.Size = new System.Drawing.Size(236, 27);
            this.txt_Cognome.TabIndex = 2;
            // 
            // lbl_Cognome
            // 
            this.lbl_Cognome.AutoSize = true;
            this.lbl_Cognome.Location = new System.Drawing.Point(57, 139);
            this.lbl_Cognome.Name = "lbl_Cognome";
            this.lbl_Cognome.Size = new System.Drawing.Size(74, 20);
            this.lbl_Cognome.TabIndex = 3;
            this.lbl_Cognome.Text = "Cognome";
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(339, 95);
            this.txt_Email.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(236, 27);
            this.txt_Email.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(339, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Email";
            // 
            // lbl_Telefono
            // 
            this.lbl_Telefono.AutoSize = true;
            this.lbl_Telefono.Location = new System.Drawing.Point(57, 224);
            this.lbl_Telefono.Name = "lbl_Telefono";
            this.lbl_Telefono.Size = new System.Drawing.Size(140, 20);
            this.lbl_Telefono.TabIndex = 6;
            this.lbl_Telefono.Text = "Numero di telefono";
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(57, 267);
            this.txt_Telefono.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(236, 27);
            this.txt_Telefono.TabIndex = 7;
            // 
            // btn_Registrati
            // 
            this.btn_Registrati.Location = new System.Drawing.Point(57, 405);
            this.btn_Registrati.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Registrati.Name = "btn_Registrati";
            this.btn_Registrati.Size = new System.Drawing.Size(173, 85);
            this.btn_Registrati.TabIndex = 8;
            this.btn_Registrati.Text = "Registrati";
            this.btn_Registrati.UseVisualStyleBackColor = true;
            this.btn_Registrati.Click += new System.EventHandler(this.btn_Registrati_Click);
            // 
            // btn_Indietro
            // 
            this.btn_Indietro.Location = new System.Drawing.Point(57, 499);
            this.btn_Indietro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Indietro.Name = "btn_Indietro";
            this.btn_Indietro.Size = new System.Drawing.Size(173, 85);
            this.btn_Indietro.TabIndex = 9;
            this.btn_Indietro.Text = "Indietro";
            this.btn_Indietro.UseVisualStyleBackColor = true;
            this.btn_Indietro.Click += new System.EventHandler(this.btn_Indietro_Click);
            // 
            // Registrati
            // 
            this.Registrati.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Registrati.Location = new System.Drawing.Point(48, -5);
            this.Registrati.Name = "Registrati";
            this.Registrati.Size = new System.Drawing.Size(182, 51);
            this.Registrati.TabIndex = 10;
            this.Registrati.Text = "Registrati";
            // 
            // btn_PagLogin
            // 
            this.btn_PagLogin.Location = new System.Drawing.Point(237, 405);
            this.btn_PagLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_PagLogin.Name = "btn_PagLogin";
            this.btn_PagLogin.Size = new System.Drawing.Size(139, 85);
            this.btn_PagLogin.TabIndex = 11;
            this.btn_PagLogin.Text = "Vai Alla Pagina di Login";
            this.btn_PagLogin.UseVisualStyleBackColor = true;
            this.btn_PagLogin.Click += new System.EventHandler(this.btn_PagLogin_Click);
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(339, 176);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(236, 27);
            this.txt_Password.TabIndex = 12;
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(339, 139);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(70, 20);
            this.lbl_Password.TabIndex = 13;
            this.lbl_Password.Text = "Password";
            // 
            // Frm_Registrati
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 600);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.btn_PagLogin);
            this.Controls.Add(this.Registrati);
            this.Controls.Add(this.btn_Indietro);
            this.Controls.Add(this.btn_Registrati);
            this.Controls.Add(this.txt_Telefono);
            this.Controls.Add(this.lbl_Telefono);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.lbl_Cognome);
            this.Controls.Add(this.txt_Cognome);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.lbl_Nome);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Frm_Registrati";
            this.Text = "Frm_Registrati";
            this.Load += new System.EventHandler(this.Frm_Registrati_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.TextBox txt_Cognome;
        private System.Windows.Forms.Label lbl_Cognome;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Telefono;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.Button btn_Registrati;
        private System.Windows.Forms.Button btn_Indietro;
        private System.Windows.Forms.Label Registrati;
        private System.Windows.Forms.Button btn_PagLogin;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label lbl_Password;
    }
}
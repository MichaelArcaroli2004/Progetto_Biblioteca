﻿
namespace Bilioteca_Bros_e_Arcaroli
{
    partial class frm_DatiUtente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_libriPersonali = new System.Windows.Forms.Button();
            this.lbl_CognomeUtente = new System.Windows.Forms.Label();
            this.lbl_EmailUtente = new System.Windows.Forms.Label();
            this.lbl_TelefonoUtente = new System.Windows.Forms.Label();
            this.lbl_Telefono = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_Cognome = new System.Windows.Forms.Label();
            this.lbl_NomeUtente = new System.Windows.Forms.Label();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_libriPersonali
            // 
            this.btn_libriPersonali.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_libriPersonali.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_libriPersonali.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_libriPersonali.Location = new System.Drawing.Point(113, 275);
            this.btn_libriPersonali.Name = "btn_libriPersonali";
            this.btn_libriPersonali.Size = new System.Drawing.Size(142, 44);
            this.btn_libriPersonali.TabIndex = 17;
            this.btn_libriPersonali.Text = "I miei libri";
            this.btn_libriPersonali.UseVisualStyleBackColor = true;
            this.btn_libriPersonali.Click += new System.EventHandler(this.btn_libriPersonali_Click);
            // 
            // lbl_CognomeUtente
            // 
            this.lbl_CognomeUtente.AutoSize = true;
            this.lbl_CognomeUtente.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_CognomeUtente.Location = new System.Drawing.Point(176, 88);
            this.lbl_CognomeUtente.Name = "lbl_CognomeUtente";
            this.lbl_CognomeUtente.Size = new System.Drawing.Size(50, 20);
            this.lbl_CognomeUtente.TabIndex = 16;
            this.lbl_CognomeUtente.Text = "label2";
            // 
            // lbl_EmailUtente
            // 
            this.lbl_EmailUtente.AutoSize = true;
            this.lbl_EmailUtente.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_EmailUtente.Location = new System.Drawing.Point(176, 140);
            this.lbl_EmailUtente.Name = "lbl_EmailUtente";
            this.lbl_EmailUtente.Size = new System.Drawing.Size(50, 20);
            this.lbl_EmailUtente.TabIndex = 15;
            this.lbl_EmailUtente.Text = "label2";
            // 
            // lbl_TelefonoUtente
            // 
            this.lbl_TelefonoUtente.AutoSize = true;
            this.lbl_TelefonoUtente.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_TelefonoUtente.Location = new System.Drawing.Point(176, 191);
            this.lbl_TelefonoUtente.Name = "lbl_TelefonoUtente";
            this.lbl_TelefonoUtente.Size = new System.Drawing.Size(50, 20);
            this.lbl_TelefonoUtente.TabIndex = 14;
            this.lbl_TelefonoUtente.Text = "label2";
            // 
            // lbl_Telefono
            // 
            this.lbl_Telefono.AutoSize = true;
            this.lbl_Telefono.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Telefono.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Telefono.Location = new System.Drawing.Point(59, 187);
            this.lbl_Telefono.Name = "lbl_Telefono";
            this.lbl_Telefono.Size = new System.Drawing.Size(86, 25);
            this.lbl_Telefono.TabIndex = 13;
            this.lbl_Telefono.Text = "Telefono";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Email.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Email.Location = new System.Drawing.Point(59, 135);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(58, 25);
            this.lbl_Email.TabIndex = 12;
            this.lbl_Email.Text = "Email";
            // 
            // lbl_Cognome
            // 
            this.lbl_Cognome.AutoSize = true;
            this.lbl_Cognome.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Cognome.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Cognome.Location = new System.Drawing.Point(59, 84);
            this.lbl_Cognome.Name = "lbl_Cognome";
            this.lbl_Cognome.Size = new System.Drawing.Size(93, 25);
            this.lbl_Cognome.TabIndex = 11;
            this.lbl_Cognome.Text = "Cognome";
            // 
            // lbl_NomeUtente
            // 
            this.lbl_NomeUtente.AutoSize = true;
            this.lbl_NomeUtente.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_NomeUtente.Location = new System.Drawing.Point(176, 42);
            this.lbl_NomeUtente.Name = "lbl_NomeUtente";
            this.lbl_NomeUtente.Size = new System.Drawing.Size(50, 20);
            this.lbl_NomeUtente.TabIndex = 10;
            this.lbl_NomeUtente.Text = "label2";
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Nome.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Nome.Location = new System.Drawing.Point(59, 37);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(63, 25);
            this.lbl_Nome.TabIndex = 9;
            this.lbl_Nome.Text = "Nome";
            // 
            // frm_DatiUtente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 367);
            this.Controls.Add(this.btn_libriPersonali);
            this.Controls.Add(this.lbl_CognomeUtente);
            this.Controls.Add(this.lbl_EmailUtente);
            this.Controls.Add(this.lbl_TelefonoUtente);
            this.Controls.Add(this.lbl_Telefono);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lbl_Cognome);
            this.Controls.Add(this.lbl_NomeUtente);
            this.Controls.Add(this.lbl_Nome);
            this.Location = new System.Drawing.Point(2000, 0);
            this.Name = "frm_DatiUtente";
            this.Text = "frm_DatiUtente";
            this.Load += new System.EventHandler(this.frm_DatiUtente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_libriPersonali;
        private System.Windows.Forms.Label lbl_CognomeUtente;
        private System.Windows.Forms.Label lbl_EmailUtente;
        private System.Windows.Forms.Label lbl_TelefonoUtente;
        private System.Windows.Forms.Label lbl_Telefono;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_Cognome;
        private System.Windows.Forms.Label lbl_NomeUtente;
        private System.Windows.Forms.Label lbl_Nome;
    }
}